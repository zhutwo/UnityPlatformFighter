Proof of Concept Features:

-All DPS character animations, transitions, and control mechanics implemented
-Animations. transitions and some cooldowns/end lag have been tweaked for some polish but not finalized (will likely opt for quicker transitions)
-Special ability currently has no cooldown (final version will likely involve a combination cooldown/meter system that allows consecutive uses)
-Special effects necessary to convey a mechanic have been implemented; additional polish effects to be completed at later stage
-Level whiteboxed
-Character model was manually rigged in order to achieve T-pose from non T-pose source, and then fed in Mixamo


Character Controls:

A - Left
D - Right
S - Down (Crouch)
W - Up
Space - Jump (Jump again in air to double jump)
Shift - Special (Dash Slash for DPS, must be in Melee mode)
Mouse1 - Attack (Context dependent)
Mouse2 - Defend (Parry for DPS)
MouseWheel - Switch Weapon (Melee or Ranged)


Melee Attacks:

While grounded:

Neutral Attack = A 3 hit combo
Up + Attack = An upward launching uppercut
Back + Attack = A quick defensive anti-air kick
Down + Attack = A low leg sweep
Forward + Attack = A lunging attack

While airborne:

Neutral Attack OR Forward + Attack = a fast, short ranged aerial
Back + Attack = a defensive zoning aerial
Down + Attack = a downward aerial that can spike opponents
Up + Attack = an upwards aerial


NOTES:

- Aerial drift can be affected by holding down a direction
- A long press of the jump button produces a full hop
- If the jump button is released before character exits jump windup, a short hop is produced
- Double jump trajectory is affected by held direction at input
- Pressing down after apex of jump causes character to fast fall
- Landing lag is affected by rate of descent (light and hard landing)